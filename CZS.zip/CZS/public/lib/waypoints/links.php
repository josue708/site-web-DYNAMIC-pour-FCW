<?php
  $links = array(
    'js' => '../public/lib/waypoints/waypoints.min.js'
  );
?>
